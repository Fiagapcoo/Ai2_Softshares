const db = require('./models');

async function syncModels() {
    try {
        await db.sequelize.authenticate();
        console.log('Connection has been established successfully.');

        const modelNames = Object.keys(db);
        console.log('Models found:', modelNames);

        for (const modelName of modelNames) {
            if (modelName !== 'sequelize' && modelName !== 'Sequelize') {
                console.log(`Syncing model: ${modelName}`);
                await db[modelName].sync({ alter: true });
                console.log(`Synced model: ${modelName}`);
            }
        }

        console.log('All models were synchronized successfully.');
    } catch (error) {
        console.error('Unable to sync models:', error);
    } finally {
        await db.sequelize.close();
    }
}

syncModels();
